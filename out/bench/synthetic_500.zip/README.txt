ARC-SeedCatalog proof pack. No raw input JSON included.
